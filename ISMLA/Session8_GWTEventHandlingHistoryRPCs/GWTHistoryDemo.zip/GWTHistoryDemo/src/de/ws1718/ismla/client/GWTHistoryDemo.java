package de.ws1718.ismla.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>. Demonstrates the
 * usage of GWT History.
 * 
 * @author Bjoern Rudzewitz
 */
public class GWTHistoryDemo implements EntryPoint, ValueChangeHandler<String> {

	// a panel to hold the variable content
	private FlowPanel contentPanel;

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		buildStaticInterface();

		// initialize history system
		History.addValueChangeHandler(this);
		// get current token, if any
		String startingToken = History.getToken();
		// push token to history stack
		History.newItem(startingToken);
		// force the system to evaluate the current history token
		History.fireCurrentHistoryState();
	}

	/**
	 * Creates the part of the application that will remain constant. Creates a
	 * menu bar with different items to navigate the page.
	 */
	private void buildStaticInterface() {
		// create a menu bar
		MenuBar menu = new MenuBar();

		// add text item in menu
		menu.addItem("texts", new ChangeCommand("texts"));

		// add persons item in menu
	
		menu.addItem("team", new ChangeCommand("team"));
		RootPanel.get().add(menu);

		contentPanel = new FlowPanel();
		RootPanel.get().add(contentPanel);
	}
	
	/**
	 * A command to handle changes in the history.
	 * 
	 * @author bjoern
	 *
	 */
	private class ChangeCommand implements Command {

		private String histToken;
		
		
		
		public ChangeCommand(String histToken) {
			super();
			this.histToken = histToken;
		}

		@Override
		public void execute() {
			History.newItem(histToken);
		}
		
	}

	/**
	 * Handles change events in the history tokens. Called when a user uses the
	 * back and forward button in the browser or when he directly types the
	 * address with history tokens.
	 */
	@Override
	public void onValueChange(ValueChangeEvent<String> event) {

		String token = event.getValue();

		if (token == null || token.isEmpty()) {
			showStartPage();
			return;
		} else if (token.equals("texts")) {
			showTextsPage();
			return;
		} else if (token.equals("team")) {
			showTeamPage();
			return;
		}
		showErrorPage();
		return;
	}

	/**
	 * Fills the content of the page with some texts.
	 */
	private void showTextsPage() {

		// remove existing content
		contentPanel.clear();

		HTML text1 = new HTML("Lorem ipsum dolor sit amet ...");
		contentPanel.add(text1);
		HTMLPanel text2 = new HTMLPanel("a bc de fg hi jk ...");
		contentPanel.add(text2);
	}

	/**
	 * Fills the content of the page with some information about the team.
	 */
	private void showTeamPage() {

		// remove existing content
		contentPanel.clear();

		HTML person1 = new HTML("Main developer: me");
		contentPanel.add(person1);
		HTMLPanel person2 = new HTMLPanel("Main tester: me");
		contentPanel.add(person2);
	}

	/**
	 * Fills the content of the page with a start screen.
	 */
	private void showStartPage() {

		// remove existing content
		contentPanel.clear();

		HTML startText = new HTML("<h2>Welcome!</h2><br>This is a GWT History demo.");
		contentPanel.add(startText);
	}

	/**
	 * Fills the content of the page with an error text.
	 */
	private void showErrorPage() {

		// remove existing content
		contentPanel.clear();

		HTML errorText = new HTML("<h2>Error:</h2> page does not exist.");
		contentPanel.add(errorText);
	}
}
