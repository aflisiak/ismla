package de.ws1718.ismla.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>. Minimal example for event handling.
 * 
 * @author Bjoern Rudzewitz
 */
public class GWTEventHandlingDemo implements EntryPoint {

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		// demonstration of click handler
		VerticalPanel verticalPanel = new VerticalPanel();
		HTML heading = new HTML("<h2>Please type a text or click on the input field below:</h2>");
		verticalPanel.add(heading);
		TextBox tvp = new TextBox();
		verticalPanel.add(tvp);
		final HTMLPanel infoPanel = new HTMLPanel("");
		// click handler - anonymous innner class
		verticalPanel.add(infoPanel);
		;
		tvp.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				infoPanel.clear();
				infoPanel.add(new HTML("click event detected"));
			}
		});
		// click handler - private class
		tvp.addKeyPressHandler(new TextBoxKeyPresssHandler(infoPanel));
		RootPanel.get().add(verticalPanel);
	}
	

	/**
	 * A key handler for the case a user presses a key. Adds an information to an info panel.
	 * 
	 * @author bjoern
	 *
	 */
	private final class TextBoxKeyPresssHandler implements KeyPressHandler {
		// panel to add the info message to
		private final HTMLPanel infoPanel;

		private TextBoxKeyPresssHandler(HTMLPanel infoPanel) {
			this.infoPanel = infoPanel;
		}

		@Override
		public void onKeyPress(KeyPressEvent event) {
			infoPanel.clear();
			infoPanel.add(new HTML("key press event detected"));
		}
	}
}
