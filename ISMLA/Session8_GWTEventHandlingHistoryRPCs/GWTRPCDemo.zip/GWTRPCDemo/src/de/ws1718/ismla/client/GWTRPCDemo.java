package de.ws1718.ismla.client;

import java.util.ArrayList;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>. Deomnstrates the usage of RPCs and server-side processing.
 * 
 * @author Bjoern Rudzewitz
 */
public class GWTRPCDemo implements EntryPoint {
	
	/**
	 * The message displayed to the user when the server cannot be reached or
	 * returns an error.
	 */
	private static final String SERVER_ERROR = "An error occurred while "
			+ "attempting to contact the server. Please check your network " + "connection and try again.";

	/**
	 * Create a remote service proxy to talk to the server-side Greeting service.
	 */
	private final GreetingServiceAsync greetingService = GWT.create(GreetingService.class);

	private TextArea textarea;
	private FlowPanel resultPanel;
	
	
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		
		VerticalPanel vp = new VerticalPanel();
		
		HTML instr = new HTML("Please enter a text to be tokenized.");
		vp.add(instr);
		
		textarea = new TextArea();
		textarea.setWidth("300px");
		textarea.setHeight("300px");
		vp.add(textarea);
		
		Button btnSubmit = new Button("Submit");
		vp.add(btnSubmit);
		btnSubmit.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				greetingService.tokenize(textarea.getText(), new TokenizationCallback());
			}
		});
		
		Button btnSubmitWithModel = new Button("Submit and use model");
		btnSubmitWithModel.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				greetingService.tokenizeWithModel(textarea.getText(), new TokenizationCallback());
			}
		});

		vp.add(btnSubmitWithModel);
		
		resultPanel = new FlowPanel();
		vp.add(resultPanel);
		RootPanel.get().add(vp);
		
	}
	
	private final class TokenizationCallback implements AsyncCallback<ArrayList<String>> {
		@Override
		public void onFailure(Throwable caught) {
			resultPanel.clear();
			resultPanel.add(new HTML("<h3>Error:</h3> something went wrong on the server."));
		}

		@Override
		public void onSuccess(ArrayList<String> result) {
			resultPanel.clear();
			resultPanel.add(new HTML("<h3>Resulting tokens: </h3>"));
			for(String token : result){
				resultPanel.add(new Label(token));
			}
		}
	}
}
