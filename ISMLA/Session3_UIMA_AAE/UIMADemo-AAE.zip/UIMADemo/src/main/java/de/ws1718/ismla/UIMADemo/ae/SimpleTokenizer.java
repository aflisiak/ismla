package de.ws1718.ismla.UIMADemo.ae;

import java.util.ArrayList;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import de.ws1718.ismla.UIMADemo.types.Token;

/**
 * A simplistic, primitive tokenizer for illustrating the concept of Analysis
 * Engines.
 * 
 * @author bjoern
 *
 */
public class SimpleTokenizer extends JCasAnnotator_ImplBase {

	// list of delimiters to split at
	ArrayList<Character> delimiters;

	@Override
	public void initialize(UimaContext aContext) throws ResourceInitializationException {
		super.initialize(aContext);

		// initialize all delimiters
		delimiters = new ArrayList<Character>();
		delimiters.add(' ');
		delimiters.add('\n');
		delimiters.add('\r');
		delimiters.add('\t');
	}

	@Override
	public void process(JCas arg0) throws AnalysisEngineProcessException {

		// get original text
		String document = arg0.getDocumentText();

		// where the current token started (lookback)
		int begin = 0;
		// whether the tool is inside a token
		boolean inToken = false;

		for (int i = 0; i < document.length(); i++) {
			// if it transitions into a delimiter or the end of the document
			if (delimiters.contains(document.charAt(i)) || i == document.length() - 1) {

				if (inToken) {
					// create a new Token annotation
					Token token = new Token(arg0);
					token.setBegin(begin);
					token.setEnd(i);
					token.addToIndexes(arg0);
				}

				inToken = false;
			} else {
				// if it transitions into a token record beginning
				if (!inToken) {
					begin = i;
				}

				inToken = true;
			}
		}

	}

}
