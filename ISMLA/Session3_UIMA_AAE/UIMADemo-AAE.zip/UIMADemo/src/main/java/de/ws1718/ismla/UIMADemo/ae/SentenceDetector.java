package de.ws1718.ismla.UIMADemo.ae;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.analysis_engine.ResultNotSupportedException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceAccessException;
import org.apache.uima.resource.ResourceInitializationException;

import de.ws17.ismla.UIMADemo.types.Sentence;
import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.util.Span;

public class SentenceDetector extends JCasAnnotator_ImplBase {

	private SentenceDetectorME sentenceDetector;

	@Override
	public void initialize(UimaContext aContext) throws ResourceInitializationException {
		super.initialize(aContext);

		InputStream modelIn;
		try {
			modelIn = aContext.getResourceAsStream((String) aContext.getConfigParameterValue("modelPath"));

			SentenceModel model = new SentenceModel(modelIn);

			sentenceDetector = new SentenceDetectorME(model);
		} catch (ResourceAccessException e) {
			throw new ResourceInitializationException(e);
		} catch (IOException e) {
			throw new ResourceInitializationException(e);
		}

		;
	}

	@Override
	public void process(JCas arg0) throws AnalysisEngineProcessException {
		
		String docText = arg0.getDocumentText();
		
		Span sentences[] = sentenceDetector.sentPosDetect(docText);
		
		for(Span sp : sentences){
			Sentence sent = new Sentence(arg0);
			sent.setBegin(sp.getStart());
			sent.setEnd(sp.getEnd());
			sent.addToIndexes(arg0);
		}
		
		
		
	}

	
	
	
	
	
}
