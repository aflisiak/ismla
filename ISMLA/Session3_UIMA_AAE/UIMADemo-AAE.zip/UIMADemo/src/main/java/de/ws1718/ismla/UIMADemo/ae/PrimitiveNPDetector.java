package de.ws1718.ismla.UIMADemo.ae;

import java.util.HashSet;
import java.util.Iterator;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import de.ws1718.ismla.UIMADemo.types.NP;
import de.ws1718.ismla.UIMADemo.types.Token;

public class PrimitiveNPDetector extends JCasAnnotator_ImplBase {
	
	HashSet<String> articles;
	
	@Override
	public void initialize(UimaContext aContext) throws ResourceInitializationException {
		super.initialize(aContext);
		
		articles = new HashSet<String>();
		
		String articleString = (String) aContext.getConfigParameterValue("articles");
	
		String[] split = articleString.split(",");
		for(String article : split){
			articles.add(article);
		}
	
	}
	
	
	@Override
	public void process(JCas arg0) throws AnalysisEngineProcessException {
		
		
		Iterator<Token> tokenIter  = arg0.getAnnotationIndex(Token.class).iterator();
		
		while(tokenIter.hasNext()){
			Token token = tokenIter.next();
			
			String text =  token.getCoveredText().toLowerCase();
			
			if(articles.contains(text) && tokenIter.hasNext()){
				
				Token quasiToken = tokenIter.next();
				
				NP np= new NP(arg0);
				np.setBegin(token.getBegin());
				np.setEnd(quasiToken.getEnd());
				np.addToIndexes(arg0);
			}
			
		}
		
	}

	
	
	
	
	
	
	
	
}
